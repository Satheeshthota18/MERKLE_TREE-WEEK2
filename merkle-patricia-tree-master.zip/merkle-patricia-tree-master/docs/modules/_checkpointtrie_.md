[merkle-patricia-tree](../README.md) › ["checkpointTrie"](_checkpointtrie_.md)

# Module: "checkpointTrie"

## Index

### Classes

* [CheckpointTrie](../classes/_checkpointtrie_.checkpointtrie.md)
