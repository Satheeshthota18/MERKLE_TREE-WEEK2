[merkle-patricia-tree](../README.md) › ["secure"](_secure_.md)

# Module: "secure"

## Index

### Classes

* [SecureTrie](../classes/_secure_.securetrie.md)
